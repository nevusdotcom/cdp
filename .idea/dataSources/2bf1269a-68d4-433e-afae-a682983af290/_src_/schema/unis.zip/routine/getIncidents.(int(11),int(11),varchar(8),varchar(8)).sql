CREATE PROCEDURE unis.getIncidents(IN flagLeido INT, IN flagResuelto INT, IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

	DECLARE flagNotFound INT;
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    
	DROP TEMPORARY TABLE IF EXISTS bounded_incidents;
    
    #Tabla intermedia
    CREATE TEMPORARY TABLE bounded_incidents(
    id INT,
    proyecto_id VARCHAR(30),
    proyecto_nombre VARCHAR(30),
    fecha INT,
    hora INT,
    rut VARCHAR(30),
    codigo_persona INT,
    nombre_persona VARCHAR (64),
    glosa VARCHAR(250),
    status_asistencia INT,
    #area VARCHAR(50),
    departamento VARCHAR(30), #C_POST
    telefono VARCHAR(150),
    foto BLOB
    );
    
    INSERT INTO bounded_incidents SELECT  
    incidents.incidents_ID,
	incidents.c_office,
	coffice.c_name,
    incidents.incidents_date,
    incidents.incidents_time, 
    CONCAT(CAST(tuser.tuser_rut AS CHAR),'-',tuser.tuser_verificador), 
    incidents.L_UID,
    tuser.C_Name,
    incidents.incidents_description, 
    temploye.assistance_status_id, 
    #'area', POR IMPLEMENTAR
    cpost.c_name,
    reclutamiento.telefono,
    iuserpicture.B_Picture
    FROM incidents
    JOIN tuser ON tuser.L_ID=incidents.L_UID
    JOIN coffice ON coffice.c_code=incidents.c_office
    JOIN temploye ON temploye.L_UID=incidents.L_UID
    LEFT JOIN iuserpicture ON iuserpicture.L_UID=tUser.L_ID
    LEFT JOIN cpost ON temploye.C_Post=cpost.c_code
	LEFT JOIN reclutamiento ON reclutamiento.L_UID=incidents.L_UID
    WHERE incidents.action_status=flagResuelto 
    AND incidents.read_status=flagLeido
    AND CAST(incidents.incidents_date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
    ORDER BY incidents.incidents_date,incidents.incidents_time;
    
    SELECT 
    id as 'id',
    proyecto_id as 'proyecto_id',
    proyecto_nombre as 'proyecto_nombre',
    date_format(STR_TO_DATE(fecha,'%Y%m%d'),'%Y/%m/%d') as 'fecha',#DATE_FORMAT(STR_TO_DATE(fecha,'%Y%m%d'),'%Y/%m/%d') as 'fecha',
    DATE_FORMAT(STR_TO_DATE(hora,'%H%i%s'),'%T') as 'hora',
    rut as 'rut',
    codigo_persona as 'codigo',
    nombre_persona as 'nombre',
    glosa as 'string',
    status_asistencia as 'status',
    #area VARCHAR(50),
    departamento as 'departamento', #C_POST
    telefono as 'telefono',
    HEX(foto) as 'B_Picture'
    FROM bounded_incidents;
    
END;
