CREATE PROCEDURE unis.testStored_2(IN cRemark VARCHAR(50))
  BEGIN

DECLARE LALA VARCHAR(50);
SET LALA=cRemark;

IF (LALA='all') THEN set LALA='?';   END IF;

select * from temploye where temploye.C_Remark=LALA;

END;
