CREATE PROCEDURE unis.getWorkerStats(IN workerId INT, IN actualDate VARCHAR(8))
  BEGIN

	DECLARE flagNotFound,
    ACTUAL_totalRealHours,
    ACTUAL_totalFixedHours,
    ACTUAL_workedDays,
    ACTUAL_lateDays,
    ACTUAL_assistance_status_id
    INT;
    DECLARE actualMonth VARCHAR(6);
    DECLARE actualNameStatusAssistance VARCHAR(20);
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    SET actualMonth=SUBSTR(actualDate,1,6);
    SET lc_time_names = 'es_MX';
    
	DROP TEMPORARY TABLE IF EXISTS bounded_dailyStats_distinct;
	CREATE TEMPORARY TABLE bounded_dailyStats_distinct(
    id INT,
    totalRealHours INT,
    totalFixedHours INT,
    fecha INT);
    
    INSERT INTO bounded_dailyStats_distinct SELECT daily_stats.id, MAX(daily_stats.daily_stats_h_reales),MAX(daily_stats.daily_stats_h_fixed),daily_stats.daily_stats_date
    FROM daily_stats WHERE daily_stats.L_UID=workerId 
    AND SUBSTR(daily_stats.daily_stats_date,1,6)=actualMonth
    GROUP BY daily_stats.daily_stats_date;
    
	DROP TEMPORARY TABLE IF EXISTS bounded_dailyStats;
    #Tabla intermedia
    CREATE TEMPORARY TABLE bounded_dailyStats(
    L_ID INT,
    C_Name VARCHAR (64),
    C_RegDate VARCHAR (64), #tuser
    C_Phone VARCHAR(150), #de reclutamiento
    C_Email VARCHAR(255), #temploye
    C_Remark VARCHAR(255),
    office VARCHAR(30),
    B_Picture BLOB,
    departament VARCHAR(30),
    cargo VARCHAR(255), #de reclutamiento
    especialidad VARCHAR(255), #de reclutamiento
    totalRealTimeWorked INT,
    totalFixedHours INT,
    totalWorkedDays INT
    );
    
	SELECT  temploye.assistance_status_id
    INTO ACTUAL_assistance_status_id
    FROM temploye WHERE temploye.L_UID=workerId;
    
    CASE
    WHEN ACTUAL_assistance_status_id=1 THEN
    SET actualNameStatusAssistance='NORMAL';
	WHEN ACTUAL_assistance_status_id=2 THEN
    SET actualNameStatusAssistance='LICENCIA';
	WHEN ACTUAL_assistance_status_id=3 THEN
    SET actualNameStatusAssistance='DESCANSO';
    ELSE
    SET actualNameStatusAssistance='NO ASIGNADO';
    END CASE;
    
    SELECT SUM(bounded_dailyStats_distinct.totalRealHours), SUM(bounded_dailyStats_distinct.totalFixedHours)
    INTO ACTUAL_totalRealHours, ACTUAL_totalFixedHours
    FROM bounded_dailyStats_distinct;
    #JOIN bounded_dailyStats_distinct ON bounded_dailyStats_distinct.id=daily_stats.id;
    
	SELECT COUNT(DISTINCT(tenter.C_Date)) 
    INTO ACTUAL_workedDays
    FROM tenter
    JOIN tenter2 ON tenter.tenter_id=tenter2.ID
    WHERE tenter2.L_UID=workerId AND SUBSTR(tenter.C_Date,1,6)=actualMonth COLLATE utf8_general_ci
    AND (tenter2.L_Mode=5 OR tenter2.L_Mode=3);
    #GROUP BY tenter.C_Date;

    SELECT COUNT(DISTINCT(tenter.C_Date))
	INTO ACTUAL_lateDays
    FROM tenter
    JOIN tenter2 ON tenter.tenter_id=tenter2.ID
    WHERE tenter2.L_UID=workerId AND SUBSTR(tenter.C_Date,1,6)=actualMonth COLLATE utf8_general_ci
    AND tenter2.L_Mode=3;
    
    #SELECT COUNT(bounded_dailyStats_distinct.fecha)
    #INTO ACTUAL_workedDays
    #FROM bounded_dailyStats_distinct
    #JOIN bounded_dailyStats_distinct ON bounded_dailyStats_distinct.id=daily_stats.id
    #WHERE bounded_dailyStats_distinct.totalRealHours>0;
    
	#SELECT COUNT(tenter2.L_MODE)
    #FROM tenter2
    #JOIN tenter ON tenter2.ID=tenter.tenter_id
    #JOIN bounded_dailyStats_distinct ON bounded_dailyStats_distinct.id=daily_stats.id
    #WHERE tenter2.L_UID=workerId 
    #AND SUBSTR(tenter.C_Date,1,6)=actualMonth COLLATE utf8_general_ci;
    
    INSERT INTO bounded_dailyStats SELECT  
    workerId,#L_ID INT,
    tuser.C_Name,#C_Name VARCHAR (64),
    tuser.C_RegDate,#C_RegDate VARCHAR (64), #tuser
    reclutamiento.telefono,#C_Phone VARCHAR(150), #de reclutamiento
    temploye.C_Email,#C_Email VARCHAR(255), #temploye
    temploye.C_Remark, #C_Remark VARCHAR(255),
    coffice.c_name,#office VARCHAR(30),
    iuserpicture.B_Picture,#B_Picture,
    cpost.c_name,#departament VARCHAR(30),
    reclutamiento.cargo,#cargo VARCHAR(255), #de reclutamiento
    reclutamiento.especialidad,#especialidad VARCHAR(255), #de reclutamiento
    ACTUAL_totalRealHours,#totalRealTimeWorked INT,
    ACTUAL_totalFixedHours,#totalFixedHours INT,
    ACTUAL_workedDays#totalWorkedDays INT
    FROM temploye
    JOIN tuser ON tuser.L_ID=temploye.L_UID
    LEFT JOIN coffice ON coffice.c_code=temploye.C_Office
    LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
    #JOIN temploye ON temploye.L_UID=incidents.L_UID
    LEFT JOIN cpost ON temploye.C_Post=cpost.c_code
	LEFT JOIN reclutamiento ON reclutamiento.L_UID=tuser.L_ID
    WHERE tuser.L_ID=workerId;
   
    SELECT 
	L_ID as 'L_ID',
    UPPER(C_Name) as 'C_Name',
    C_RegDate as 'C_RegDate', #tuser
    C_Phone 'C_Phone', #de reclutamiento
    UPPER(C_Email) as 'C_Email', #temploye
    actualNameStatusAssistance as 'assistance_status',
    UPPER(C_Remark) as 'C_Remark',
    UPPER(office) as 'office',
    HEX(B_Picture) as 'B_Picture',
    UPPER(departament) as 'departament',
    UPPER(cargo) as 'cargo', #de reclutamiento
    UPPER(especialidad) as 'especialidad', #de reclutamiento
    UPPER(date_format(str_to_date(CAST(month(now()) AS CHAR),'%m'),'%M')) as 'month',
    totalRealTimeWorked as 'real_hours',
    totalFixedHours as 'fixed_hours',
    totalWorkedDays as 'total_days',
    ACTUAL_lateDays as 'late_days'
    FROM bounded_dailyStats;
    
END;
