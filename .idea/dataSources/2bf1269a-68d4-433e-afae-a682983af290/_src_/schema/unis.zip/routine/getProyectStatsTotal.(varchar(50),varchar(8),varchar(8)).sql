CREATE PROCEDURE unis.getProyectStatsTotal(IN proyectName VARCHAR(50), IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

    DECLARE flagNotFound, filaActual, cantidadFilas, fechaActual INT;
    DECLARE asistencias_ACTUAL ,descansos_ACTUAL,atrasados_ACTUAL,licencias_ACTUAL,finiquitados_ACTUAL,contratados_ACTUAL,acreditados_ACTUAL,registrados_ACTUAL, fallas_ACTUAL, proceso_de_contratacion_ACTUAL INT default 0;
    DECLARE id_proyectoActual VARCHAR(30);
	
    DECLARE cursorFechasIntervalo CURSOR FOR SELECT DISTINCT tenter.C_Date FROM tenter WHERE CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);
    
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    
	DROP TEMPORARY TABLE IF EXISTS bounded_tenter;
    
    #Tabla intermedia
    CREATE TEMPORARY TABLE bounded_tenter(
    C_Date VARCHAR(8),
    c_Time_Entrada VARCHAR(6),
    c_Time_Salida VARCHAR(6),
    C_Name VARCHAR(30),
    L_UID INT,
    C_Post VARCHAR (30),
    C_Card VARCHAR (24),
    tenter_id INT,
    #coffice_name VARCHAR(30),
    #coffice_id INT,
    AREA_ID INT,
    SHIFT_ID INT,
    STATUS_ID INT,
    ASSISTANCE_STATUS_ID INT,
    ACCREDITED_ID INT
    );
    
    INSERT INTO bounded_tenter SELECT  
    tenter.C_Date,
    #tenter.c_Time , 
	MIN(tenter.C_Time),
	MAX(tenter.C_Time),
    tenter.C_Name, 
    tenter.L_UID, 
    tenter.C_Post, 
    tenter.C_Card, 
    tenter.tenter_id, 
    #coffice.c_name,
    #coffice.coffice_id,
    tenter2.AREA_ID,
    tenter2.SHIFT_ID,
    tenter2.STATUS_ID,
    #STATUS PROVENIENTE DE RECLUTAMIENTO
    #1 SELECCIONADO
    #2 CONFIRMADO
    #3 CONTRATADO
    #4 FINIQUITADO
    tenter2.ASSISTANCE_STATUS_ID, #STATUS PROVENIENTE DE ASISTENCIA
    tenter2.ACCREDITED_ID
    FROM tenter
    JOIN coffice ON coffice.c_code=tenter.C_Office
    JOIN tenter2 ON tenter.tenter_id=tenter2.ID
    #JOIN call unis.getAsistenciaB('20170428','20170510') as asistencia ON asistencia.L_ID=tenter2.ID AND asistencia.C_Date=tenter.C_Date
    WHERE coffice.c_name=proyectName
    AND tenter.L_UID > 0 AND CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
    GROUP BY tenter.C_Date,tenter.L_UID;
    
    DROP TEMPORARY TABLE IF EXISTS proyectStats;
    
    #PORCENTAJES
    #licencia medica
    #finiquitados
    #proceso de contratacion
    #permisos
    #examen medico
    
    #Tabla de resultado
    create temporary table proyectStats(
    dateStats VARCHAR(8),
    total_asistencias int not null default 0,
	total_descanso int not null default 0,
    total_atrasados int not null default 0,
    total_licencia int not null default 0,
    total_finiquitado int not null default 0,
    total_contratacion int not null default 0,
    total_acreditados int not null default 0, #Cantidad acreditados
    total_registrados int not null default 0,
    total_fallas int not null default 0,
    proceso_de_contratacion int not null default 0,
    asistencias_porcentaje int not null default 0,
    fallas_porcentaje int not null default 0,
    descanso_porcentaje int not null default 0,
    licencia_porcentaje int not null default 0,
    atrasados_porcentaje int not null default 0,
    #permisos_porcentaje int not null,
	finiquitados_porcentaje int not null default 0,
    proceso_de_contratacion_porcentaje int not null default 0,
    acreditados_porcentaje int not null default 0
    );
    
    SELECT coffice.c_code INTO id_proyectoActual FROM coffice WHERE coffice.c_name=proyectName;
    
	OPEN cursorFechasIntervalo;
    SELECT FOUND_ROWS() INTO cantidadFilas ;
    SET filaActual=0;
    
    IF (SELECT COUNT(*) FROM bounded_tenter)=0 THEN
    
    INSERT INTO proyectStats (dateStats) VALUES (DATE_FORMAT(STR_TO_DATE(CURDATE()+'','%Y%m%d'),'%Y%m%d'));
	
    SELECT COUNT( DISTINCT temploye2.L_UID) 
    INTO registrados_ACTUAL
    FROM temploye2 
    #WHERE temploye2.aggregateDate <= toDate
	WHERE temploye2.aggregateDate <= toDate
    #WHERE CAST(temploye2.aggregateDate AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
    AND temploye2.C_Office=id_proyectoActual;
    
    
	SELECT #DATE_FORMAT(STR_TO_DATE(MIN(dateStats),'%Y%m%d'),'%Y/%m/%d') as entrada,#MIN(dateStats) as inicio,
    proyectName as 'project.Nombre',
    DATE_FORMAT(STR_TO_DATE(fromDate,'%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Inicio',
	DATE_FORMAT(STR_TO_DATE(toDate,'%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Finalizacion',
    DATE_FORMAT(STR_TO_DATE(CURDATE()+'','%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Consulta',
    registrados_ACTUAL as 'project.Registrados',
    SUM(total_asistencias) as 'values.Presencias',
    SUM(total_fallas) as 'values.Faltas',
    SUM(total_descanso) as 'values.Descanso',
	SUM(total_atrasados) as 'values.Atrasados',
    SUM(total_licencia) as 'values.Licencia',
	MAX(total_registrados) as 'values.Registrados',
    AVG(finiquitados_porcentaje) as 'values.Finiquitados',
    AVG(proceso_de_contratacion_porcentaje) as 'values.Proceso de Contratacion',
    AVG(acreditados_porcentaje) as 'values.Acreditados',
    AVG(asistencias_porcentaje) as 'chart.Presencias',
    AVG(fallas_porcentaje) as 'chart.Faltas',
    AVG(descanso_porcentaje) as 'chart.Descanso',
    AVG(atrasados_porcentaje) as 'chart.Atrasados',
	AVG(licencia_porcentaje) as 'chart.Licencia'
    FROM proyectStats;
    
    ELSE
    
    WHILE filaActual<cantidadFilas DO
    
    SET filaActual=filaActual+1;
	FETCH cursorFechasIntervalo
	INTO fechaActual;
    
	SELECT COUNT( DISTINCT temploye2.L_UID) 
    INTO registrados_ACTUAL
    FROM temploye2 
    #WHERE temploye2.aggregateDate <= toDate
	WHERE temploye2.aggregateDate <= fechaActual
    AND temploye2.C_Office=id_proyectoActual;
    #AND bounded_tenter.C_Date=fechaActual;
    
    SELECT COUNT( bounded_tenter.L_UID) 
    INTO asistencias_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=1
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( bounded_tenter.L_UID) 
    INTO licencias_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=2
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( bounded_tenter.L_UID) 
    INTO descansos_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=3
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO finiquitados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.STATUS_ID=4
    AND bounded_tenter.C_Date<=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO contratados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.STATUS_ID=3
    AND bounded_tenter.C_Date<=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO proceso_de_contratacion_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.STATUS_ID<3
    AND bounded_tenter.C_Date<=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO acreditados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ACCREDITED_ID=1
    AND bounded_tenter.C_Date<=fechaActual;
    
    SET fallas_ACTUAL=registrados_ACTUAL-asistencias_ACTUAL-descansos_ACTUAL-licencias_ACTUAL;
    
	INSERT INTO proyectStats
    (dateStats,
    total_asistencias,
    total_descanso,
	total_atrasados,
    total_licencia,
    total_finiquitado,
    total_contratacion,
    total_acreditados,
    total_registrados,
    total_fallas,
    proceso_de_contratacion,
    asistencias_porcentaje,
    fallas_porcentaje,
    descanso_porcentaje,
    licencia_porcentaje,
    atrasados_porcentaje,
    #permisos_porcentaje int not null,
	finiquitados_porcentaje,
    proceso_de_contratacion_porcentaje,
    acreditados_porcentaje
    )
    VALUES
    ( fechaActual,
    asistencias_ACTUAL,
    descansos_ACTUAL,
	atrasados_ACTUAL,
	licencias_ACTUAL,
    finiquitados_ACTUAL,
    contratados_ACTUAL,
    acreditados_ACTUAL,
    registrados_ACTUAL,
    fallas_ACTUAL,
    proceso_de_contratacion_ACTUAL,
    asistencias_ACTUAL*100/registrados_ACTUAL,
    fallas_ACTUAL*100/registrados_ACTUAL,
    descansos_ACTUAL*100/registrados_ACTUAL,
    licencias_ACTUAL*100/registrados_ACTUAL,
    atrasados_ACTUAL*100/registrados_ACTUAL, #Falta implementar
    finiquitados_ACTUAL*100/registrados_ACTUAL,
    proceso_de_contratacion_ACTUAL*100/registrados_ACTUAL,
    acreditados_ACTUAL*100/registrados_ACTUAL
    );
    
    END WHILE;
    
    
    SELECT #DATE_FORMAT(STR_TO_DATE(MIN(dateStats),'%Y%m%d'),'%Y/%m/%d') as entrada,#MIN(dateStats) as inicio,
    proyectName as 'project.Nombre',
    DATE_FORMAT(STR_TO_DATE(MIN(dateStats),'%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Inicio',
	DATE_FORMAT(STR_TO_DATE(MAX(dateStats),'%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Finalizacion',
    DATE_FORMAT(STR_TO_DATE(CURDATE()+'','%Y%m%d'),'%Y/%m/%d') as 'project.Fecha de Consulta',
    MAX(total_registrados) as 'project.Registrados',
    SUM(total_asistencias) as 'values.Presencias',
    SUM(total_fallas) as 'values.Faltas',
    SUM(total_descanso) as 'values.Descanso',
	SUM(total_atrasados) as 'values.Atrasados',
    SUM(total_licencia) as 'values.Licencia',
	MAX(total_registrados) as 'values.Registrados',
    AVG(finiquitados_porcentaje) as 'values.Finiquitados',
    AVG(proceso_de_contratacion_porcentaje) as 'values.Proceso de Contratacion',
    AVG(acreditados_porcentaje) as 'values.Acreditados',
    AVG(asistencias_porcentaje) as 'chart.Presencias',
    AVG(fallas_porcentaje) as 'chart.Faltas',
    AVG(descanso_porcentaje) as 'chart.Descanso',
    AVG(atrasados_porcentaje) as 'chart.Atrasados',
	AVG(licencia_porcentaje) as 'chart.Licencia'
    FROM proyectStats;
    
    END IF;
    #end while;
    #END REPEAT;
    #CLOSE cur_1;
    #SELECT *
    #FROM
	#proyectWorkers;
  END;
