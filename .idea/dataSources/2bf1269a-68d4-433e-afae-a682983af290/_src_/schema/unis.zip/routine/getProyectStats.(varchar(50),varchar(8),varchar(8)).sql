CREATE PROCEDURE unis.getProyectStats(IN proyectName VARCHAR(50), IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

    DECLARE flagNotFound, filaActual, cantidadFilas, fechaActual INT;
    DECLARE asistencias_ACTUAL ,descansos_ACTUAL,licencias_ACTUAL,finiquitados_ACTUAL,contratados_ACTUAL,acreditados_ACTUAL,registrados_ACTUAL, fallas_ACTUAL INT default 0;
    DECLARE id_proyectoActual VARCHAR(30);
	
    DECLARE cursorFechasIntervalo CURSOR FOR SELECT DISTINCT tenter.C_Date FROM tenter WHERE CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);
    
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    
	DROP TEMPORARY TABLE IF EXISTS bounded_tenter;
    
    #Tabla intermedia
    CREATE TEMPORARY TABLE bounded_tenter(
    C_Date VARCHAR(8),
    c_Time_Entrada VARCHAR(6),
    c_Time_Salida VARCHAR(6),
    C_Name VARCHAR(30),
    L_UID INT,
    C_Post VARCHAR (30),
    C_Card VARCHAR (24),
    tenter_id INT,
    #coffice_name VARCHAR(30),
    #coffice_id INT,
    AREA_ID INT,
    SHIFT_ID INT,
    STATUS_ID INT,
    ASSISTANCE_STATUS_ID INT,
    ACCREDITED_ID INT
    );
    
    INSERT INTO bounded_tenter SELECT  
    tenter.C_Date,
    #tenter.c_Time , 
	MIN(tenter.C_Time),
	MAX(tenter.C_Time),
    tenter.C_Name, 
    tenter.L_UID, 
    tenter.C_Post, 
    tenter.C_Card, 
    tenter.tenter_id, 
    #coffice.c_name,
    #coffice.coffice_id,
    tenter2.AREA_ID,
    tenter2.SHIFT_ID,
    tenter2.STATUS_ID,
    #STATUS PROVENIENTE DE RECLUTAMIENTO
    #1 SELECCIONADO
    #2 CONFIRMADO
    #3 CONTRATADO
    #4 FINIQUITADO
    tenter2.ASSISTANCE_STATUS_ID, #STATUS PROVENIENTE DE ASISTENCIA
    tenter2.ACCREDITED_ID
    FROM tenter
    JOIN coffice ON coffice.c_code=tenter.C_Office
    JOIN tenter2 ON tenter.tenter_id=tenter2.ID
    #JOIN call unis.getAsistenciaB('20170428','20170510') as asistencia ON asistencia.L_ID=tenter2.ID AND asistencia.C_Date=tenter.C_Date
    WHERE coffice.c_name=proyectName
    AND tenter.L_UID > 0 AND CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
    GROUP BY tenter.C_Date,tenter.L_UID;
    
    DROP TEMPORARY TABLE IF EXISTS proyectStats;
    
    #Tabla de resultado
    create temporary table proyectStats(
    dateStats VARCHAR(8),
    total_asistencias int not null,
	total_descanso int not null,
    total_licencia int not null,
    total_finiquitado int not null,
    total_contratacion int not null,
    total_examen int not null, #Cantidad acreditados
    total_registrados int not null,
    total_fallas int not null
    );
    
    SELECT coffice.c_code INTO id_proyectoActual FROM coffice WHERE coffice.c_name=proyectName;
    
	OPEN cursorFechasIntervalo;
    SELECT FOUND_ROWS() INTO cantidadFilas ;
    SET filaActual=0;
    
    WHILE filaActual<cantidadFilas DO
    
    SET filaActual=filaActual+1;
	FETCH cursorFechasIntervalo
	INTO fechaActual;
    
	SELECT COUNT( DISTINCT temploye2.L_UID) 
    INTO registrados_ACTUAL
    FROM temploye2 
    #WHERE temploye2.aggregateDate <= toDate
	WHERE temploye2.aggregateDate <= fechaActual
    AND temploye2.C_Office=id_proyectoActual;
    #AND bounded_tenter.C_Date=fechaActual;
    
    SELECT COUNT( bounded_tenter.L_UID) 
    INTO asistencias_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=1
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( bounded_tenter.L_UID) 
    INTO licencias_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=2
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( bounded_tenter.L_UID) 
    INTO descansos_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ASSISTANCE_STATUS_ID=3
    AND bounded_tenter.C_Date=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO finiquitados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.STATUS_ID=4
    AND bounded_tenter.C_Date<=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO contratados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.STATUS_ID=3
    AND bounded_tenter.C_Date<=fechaActual;
    
	SELECT COUNT( DISTINCT bounded_tenter.L_UID) 
    INTO acreditados_ACTUAL
    FROM bounded_tenter 
    WHERE bounded_tenter.ACCREDITED_ID=1
    AND bounded_tenter.C_Date<=fechaActual;
    
    SET fallas_ACTUAL=registrados_ACTUAL-asistencias_ACTUAL;
    
	INSERT INTO proyectStats
    (dateStats,
    total_asistencias,
    total_descanso,
    total_licencia,
    total_finiquitado,
    total_contratacion,
    total_examen,
    total_registrados,
    total_fallas)
    VALUES
    ( fechaActual,
    asistencias_ACTUAL,
    licencias_ACTUAL,
    descansos_ACTUAL,
    finiquitados_ACTUAL,
    contratados_ACTUAL,
    acreditados_ACTUAL,
    registrados_ACTUAL,
    fallas_ACTUAL);
    
    END WHILE;
    
    SELECT * FROM proyectStats;
    #end while;
    #END REPEAT;
    #CLOSE cur_1;
    #SELECT *
    #FROM
	#proyectWorkers;
  END;
