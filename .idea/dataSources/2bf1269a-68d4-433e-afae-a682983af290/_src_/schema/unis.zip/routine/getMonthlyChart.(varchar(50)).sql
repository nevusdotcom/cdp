CREATE PROCEDURE unis.getMonthlyChart(IN stringDate VARCHAR(50))
  begin
#SET NOCOUNT ON 
declare spid varchar(100) default 'test_debug';
DECLARE presentes int default 0;
DECLARE registrados int default 0;
DECLARE percent float default 0;
DECLARE i int default 0;
DECLARE j int default 1;
DECLARE offices int default 0;
DECLARE project varchar(150) default '';
#DECLARE datala varchar (500) default '';
DECLARE dia varchar(2) default '';
DECLARE mes varchar(50) default SUBSTRING(stringDate, 5, 2);
DECLARE anio varchar(50) default SUBSTRING(stringDate, 1, 4);
DECLARE consulta varchar(100) default '';
declare outStatus varchar(50) default '';

declare continue HANDLER for 1051
set outStatus='ya existia tabla temp';

#
drop table unis.resultado;
create temporary table unis.resultado
(
    rama varchar(150) not null,
    dia01 float not null default 0,
    dia02 float not null default 0,
    dia03 float not null default 0,
    dia04 float not null default 0,
    dia05 float not null default 0,
    dia06 float not null default 0,
    dia07 float not null default 0,
    dia08 float not null default 0,
    dia09 float not null default 0,
    dia10 float not null default 0,
    dia11 float not null default 0,
    dia12 float not null default 0,
    dia13 float not null default 0,
    dia14 float not null default 0,
    dia15 float not null default 0,
    dia16 float not null default 0,
    dia17 float not null default 0,
    dia18 float not null default 0,
    dia19 float not null default 0,
    dia20 float not null default 0,
    dia21 float not null default 0,
    dia22 float not null default 0,
    dia23 float not null default 0,
    dia24 float not null default 0,
    dia25 float not null default 0,
    dia26 float not null default 0,
    dia27 float not null default 0,
    dia28 float not null default 0,
    dia29 float not null default 0,
    dia30 float not null default 0,
    dia31 float not null default 0
 );

  select count(*) into offices from cOffice;

  while i < offices do
	SET i = i+1;
      SELECT cOffice.c_name
      into project
      FROM cOffice
      WHERE cOffice.coffice_id = i;
      #call debug_on(concat('dia:', cast(i as char),' ',project));
      insert into unis.resultado(rama) values (project); 
      commit;
      
      SET j=0;
      WHILE j < 31
      do
      SET j=j+1;
      	IF j < 10 then
              SET dia = CONCAT ('0',cast(j AS CHAR(2)));
          ELSE
              SET dia = cast(j AS CHAR(2));
            end if;
          #PRINT @day;
          #call debug_on(dia);
          select count(DISTINCT tUser.L_ID)
          into registrados
          FROM tUser
            INNER JOIN tEmploye ON tUser.L_ID = tEmploye.L_UID
            INNER JOIN cOffice ON tEmploye.C_Office = cOffice.c_code
          WHERE
            cOffice.c_name = project
            AND CAST(tUser.C_RegDate AS signed) < CAST(concat(anio,mes, dia,'235959') AS SIGNED);
		
			#call debug_on(concat('dia:', cast(dia as char),' ',project,'--registrados:',cast(registrados as char),'--proyecto::',project,'--fecha::',anio , mes , dia , '235959'));

          select count(distinct tuser.L_ID) into presentes
          FROM coffice
            INNER JOIN tEmploye ON tEmploye.C_Office = cOffice.c_code
            INNER JOIN tEnter ON tEmploye.L_UID = tEnter.L_UID
            INNER JOIN tUser ON tEmploye.L_UID = tUser.L_ID
          WHERE
            tUser.L_ID > 0
            AND tEnter.C_Date = concat(anio, mes , dia) ##revisar like
            AND cOffice.c_name = project
            AND tEnter.L_Mode != 4 AND tEnter.L_Mode != 2 AND tEmploye.C_Staff = '0001';
          
		#call debug_on(concat('dia:', cast(dia as char),' ',project,'--presentes:',cast(presentes as char),'--proyecto::',project,'--fecha::',anio , mes , dia , '235959'));

          
          IF registrados > 0 then
              SET percent = (CAST(presentes AS decimal) / CAST(registrados AS decimal) * 100);
            #END
          ELSE
            #BEGIN
              SET percent = 0;
            end if;
          
          SET @s = CONCAT('UPDATE unis.resultado SET dia',dia,'=',cast(percent as char),' WHERE rama=',''',project,''');
          PREPARE stmt FROM @s;
          EXECUTE stmt;
          DEALLOCATE PREPARE stmt;
          commit;
          #call debug_on(project);

          #SET j =j+1;
        end while;
      #SET i = i+1;
    end while;
  select * from unis.resultado;
end;
