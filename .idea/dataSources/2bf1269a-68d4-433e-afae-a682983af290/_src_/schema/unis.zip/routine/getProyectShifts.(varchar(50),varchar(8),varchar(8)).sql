CREATE PROCEDURE unis.getProyectShifts(IN proyectName VARCHAR(50), IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

    DECLARE shift_id_ACTUAL, flagNotFound, cantidadFilas, filaActual,numberOfWorkers_ACTUAL INT ;
    DECLARE shift_name_ACTUAL VARCHAR(50);
    
    DECLARE cur_1 CURSOR FOR SELECT DISTINCT tenter2.SHIFT_ID
    FROM tenter2
	JOIN tenter ON tenter.L_UID=tenter2.L_UID
    JOIN coffice ON coffice.c_code=tenter.C_Office
    WHERE coffice.c_name=proyectName
    AND tenter.L_UID > 0 AND CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);

	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    DROP TEMPORARY TABLE IF EXISTS proyectShifts;
    
    create temporary table proyectShifts(
    shift_id int,
    shift_name varchar(50) default '',
	numberOfWorkers int
    );

    OPEN cur_1;
    select FOUND_ROWS() into cantidadFilas ;
    SET filaActual=0;
    
    WHILE filaActual<cantidadFilas DO
    
    FETCH cur_1 INTO shift_id_ACTUAL;
    SET filaActual=filaActual+1;
    SET shift_name_ACTUAL='';    
 
	#call unis.debug_on(concat(actualWorkerId));
    SELECT shift.shift_name INTO shift_name_ACTUAL
    FROM shift
    WHERE shift.shift_id=shift_id_ACTUAL;
    
	SELECT COUNT(DISTINCT tenter2.L_UID) INTO numberOfWorkers_ACTUAL
    FROM tenter2
	JOIN tenter ON tenter.tenter_id=tenter2.ID
    #JOIN coffice ON coffice.c_code=tenter.C_Office
    #WHERE coffice.c_name=proyectName
    WHERE tenter2.SHIFT_ID=shift_id_ACTUAL
    AND tenter2.L_UID > 0 AND CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);

    INSERT INTO proyectShifts
    (shift_id,
    shift_name,
    numberOfWorkers)
    VALUES
    ( shift_id_ACTUAL,
    shift_name_ACTUAL,#
    numberOfWorkers_ACTUAL);

    end WHILE;
    #END REPEAT;
    CLOSE cur_1;
    SELECT shift_id as 'shift.id', shift_name as 'shift.nombre', numberOfWorkers as 'shift.cantidad'
    FROM
	proyectShifts;
  END;
