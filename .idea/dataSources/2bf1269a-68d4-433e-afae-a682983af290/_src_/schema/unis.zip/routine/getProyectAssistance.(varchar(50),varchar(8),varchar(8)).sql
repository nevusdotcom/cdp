CREATE PROCEDURE unis.getProyectAssistance(IN proyectName VARCHAR(50), IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

    DECLARE flagNotFound, filaActual, cantidadFilas, fechaActual INT;
    DECLARE asistencias_ACTUAL ,descansos_ACTUAL,licencias_ACTUAL,finiquitados_ACTUAL,contratados_ACTUAL,acreditados_ACTUAL,registrados_ACTUAL, fallas_ACTUAL INT default 0;
    DECLARE id_proyectoActual VARCHAR(30);
	
    DECLARE cursorFechasIntervalo CURSOR FOR SELECT DISTINCT tenter.C_Date FROM tenter WHERE CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);
    
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    
	DROP TEMPORARY TABLE IF EXISTS bounded_tenter;
    
    CREATE TEMPORARY TABLE bounded_tenter(
    C_Date VARCHAR(8),
    c_Time_Entrada VARCHAR(6),
    c_Time_Salida VARCHAR(6),
    C_Name VARCHAR(30),
    RUT VARCHAR(50),
    L_UID INT,
    C_Post VARCHAR (30),
    C_Card VARCHAR (24),
    tenter_id INT,
    AREA_ID INT,
    SHIFT_ID INT,
    STATUS_ID INT,
    ASSISTANCE_STATUS_ID INT,  #'worker.situacion', 
    ACCREDITED_ID INT,
    L_MODE INT,
    # ---- RECLUTAMIENTO ----
    REC_CODIGO INT, 
	REC_NOMBRES VARCHAR(50),
	REC_APE1 VARCHAR(150),
	REC_APE2 VARCHAR(150),
    REC_ESPECIALIDAD VARCHAR(255),
    REC_CARGO VARCHAR(255),
    REC_INICIO_CONTRATO DATETIME,
    REC_TURNO VARCHAR(255) ,
    # ---- DESDE TENTER2 ----
    REC_AREA VARCHAR(50), #### SE TIENE QUE REALIZAR JOIN CON area_terminal
    # ---- RECLUTAMIENTO ----
    REC_TELEFONO VARCHAR(150),
	REC_REGION VARCHAR(350),
    REC_PROVINCIA VARCHAR(350),
    REC_COMUNA VARCHAR(350),
	REC_CONTRATO VARCHAR(50),
    REC_FECHA_FINIQUITO DATETIME,
	REC_TERMINO_CONTRATO DATETIME
    );
    
    INSERT INTO bounded_tenter SELECT  
    tenter.C_Date,
	MIN(tenter.C_Time),
	MAX(tenter.C_Time),
    tenter.C_Name,
    reclutamiento.rut,
    tenter.L_UID, 
    tenter.C_Post, 
    tenter.C_Card, 
    tenter.tenter_id, 
    tenter2.AREA_ID,
    tenter2.SHIFT_ID,
    tenter2.STATUS_ID,
    tenter2.ASSISTANCE_STATUS_ID,
    tenter2.ACCREDITED_ID,
    tenter2.L_MODE,
	reclutamiento.USER_ID ,#REC_CODIGO INT, 
	reclutamiento.nombre ,#REC_NOMBRES VARCHAR(50),
	reclutamiento.ape1 ,#REC_APE1 VARCHAR(150),
	reclutamiento.ape2 ,#REC_APE2 VARCHAR(150),
    reclutamiento.especialidad ,#REC_ESPECIALIDAD VARCHAR(255),
    reclutamiento.cargo ,#REC_CARGO VARCHAR(255),
    reclutamiento.inicioContrato ,#REC_INICIO_CONTRATO DATETIME,
    reclutamiento.turno ,#REC_TURNO VARCHAR(255) ,
    area.nombre,####tenter2. ,#REC_AREA VARCHAR(50),  FALTA POR CREAR JOIN CON area_terminal
    reclutamiento.telefono ,#REC_TELEFONO VARCHAR(150),
	reclutamiento.region ,#REC_REGION VARCHAR(350),
    reclutamiento.provincia ,#REC_PROVINCIA VARCHAR(350),
    reclutamiento.comuna ,#REC_COMUNA VARCHAR(350),
	reclutamiento.contrato_id ,#REC_CONTRATO VARCHAR(50),
    reclutamiento.fecha_finiquito ,#REC_FECHA_FINIQUITO DATETIME,
	reclutamiento.fecha_termino #REC_TERMINO_CONTRATO DATETIME
    
    FROM tenter
    JOIN coffice ON coffice.c_code=tenter.C_Office
    JOIN tenter2 ON tenter.tenter_id=tenter2.ID
    JOIN area_terminal ON area_terminal.AREA_ID=tenter2.AREA_ID
    JOIN area ON area.ID=area_terminal.AREA_ID
    JOIN reclutamiento ON tenter.L_UID=reclutamiento.L_UID
    WHERE coffice.c_name=proyectName
    AND tenter.L_UID > 0 AND CAST(tenter.C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
    GROUP BY tenter.C_Date,tenter.L_UID #tenter.C_Name;#tenter.C_Date,tenter.L_UID;
    ORDER BY tenter.C_Name,tenter.C_Date;
    
    SELECT 
    bounded_tenter.C_Date as 'worker.fecha',
    bounded_tenter.c_Time_Entrada as 'worker.entrada',
    bounded_tenter.c_Time_Salida as 'worker.salida',
    bounded_tenter.L_UID as 'worker.codigo',
    bounded_tenter.RUT as 'worker.rut' ,
    bounded_tenter.REC_NOMBRES as 'worker.nombres' ,
	bounded_tenter.REC_APE1 as 'worker.ape1' ,
	bounded_tenter.REC_APE2 as 'worker.ape2' ,
    bounded_tenter.REC_ESPECIALIDAD as 'worker.especialidad' ,
    bounded_tenter.REC_CARGO as 'worker.cargo' ,
    bounded_tenter.REC_INICIO_CONTRATO as 'worker.inicioContrato' ,
    bounded_tenter.REC_TURNO as 'worker.turno' ,
    bounded_tenter.ASSISTANCE_STATUS_ID as 'worker.situacion', #estado asistencia 
    bounded_tenter.REC_AREA as 'worker.area',
    ####bounded_tenter.L_UID as 'worker.observaciones',
    bounded_tenter.REC_TELEFONO as 'worker.telefono',
	bounded_tenter.REC_REGION as 'worker.region',
	bounded_tenter.REC_PROVINCIA as 'worker.provincia',
	bounded_tenter.REC_COMUNA as 'worker.comuna',
	bounded_tenter.REC_CONTRATO as 'worker.contrato',
    bounded_tenter.REC_FECHA_FINIQUITO as 'worker.fechaFiniquito',
	bounded_tenter.REC_TERMINO_CONTRATO as 'worker.terminoContrato'
    FROM bounded_tenter;
    
END;
