CREATE PROCEDURE unis.getWorkerData(IN id INT, IN day VARCHAR(8))
  BEGIN
declare month varchar(2) default '';
declare month_str varchar(50) default '';
SET month = substr(day,5,2);
SET lc_time_names = 'es_MX';
SET month_str = upper(date_format(str_to_date('01','%c'),'%M'));
SELECT
  tUser.L_ID,
  tUser.C_Name,
  tUser.C_RegDate,
  tEmploye.C_Phone,
  tEmploye.C_Email,
  tEmploye.C_Remark,
  upper(cOffice.c_name)       office,
  HEX(iUserPicture.B_Picture) B_Picture,
  cPost.c_name AS             departament,
  reclutamiento.cargo
FROM tUser
  left JOIN tEmploye ON tUser.L_ID = tEmploye.L_UID
  left JOIN cOffice ON tEmploye.C_Office = cOffice.c_code
  left JOIN reclutamiento ON reclutamiento.L_UID = tuser.L_ID
  LEFT JOIN cPost ON tEmploye.C_Post = cPost.c_code
  LEFT JOIN iUserPicture ON tUser.L_ID = iUserPicture.L_UID
WHERE tUser.L_ID = id;
SET lc_time_names = 'en_US';


#####################################################################################
#	SP INCLOMPLETO FALTA COMPLEMENTAR CON LOS STATS DE ESTE TRABAJDO EN EL MES		#	
#	CONTENIDO EN LA VARIABLE month. ESTO SEGUN ARRAY ESPECIFICADO EN EL JSON DE		#
#	DUMMY DATA EN SILEX EN EL SERVICIO: UserService EN EL METODO getOneByParam.		#
#####################################################################################

END;
