CREATE PROCEDURE unis.debug_insert(IN p_proc_id VARCHAR(100), IN p_debug_info TEXT)
  begin
  insert into debug (id,debug_output)
  values (p_proc_id,p_debug_info);
end;
