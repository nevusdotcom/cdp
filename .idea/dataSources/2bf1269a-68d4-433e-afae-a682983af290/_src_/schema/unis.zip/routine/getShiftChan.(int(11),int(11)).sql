CREATE FUNCTION unis.getShiftChan(idTurno INT, inTimeActual INT)
  RETURNS INT
  BEGIN

	DECLARE diferenciaActual, L_Mode INT;#, #estadoTiempoLlegada INT;
    DECLARE timeStack INT default 10000;
    DECLARE filaStack INT default 0;
    #DECLARE colNameActual VARCHAR(64);
    
	DECLARE timeShiftCursor CURSOR FOR 
	SELECT ABS(shift.shift_early_entrance_f-inTimeActual) AS TIMESHIFT,6 AS TIMESHIFTCODE  FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_early_entrance_t-inTimeActual),7 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
	SELECT ABS(shift.shift_normal_entrance_f-inTimeActual),8 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_normal_entrance_t-inTimeActual),9 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_late_entrance_t-inTimeActual),10 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_late_entrance_f-inTimeActual),11 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_early_depart_t-inTimeActual),14 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_early_depart_f-inTimeActual),15 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_normal_depart_t-inTimeActual),16 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_normal_depart_f-inTimeActual),17 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_late_depart_t-inTimeActual),18 FROM unis.shift WHERE shift.shift_id=idTurno
    UNION ALL
    SELECT ABS(shift.shift_late_depart_f-inTimeActual),19 FROM unis.shift WHERE shift.shift_id=idTurno
    ORDER BY TIMESHIFT ASC
    LIMIT 1;
    
    OPEN timeShiftCursor;
    FETCH timeShiftCursor INTO diferenciaActual, filaStack;
        
    CASE
		#shift_early_entrance_f #shift_early_entrance_t #ENTRADA TEMPRANA
        WHEN filaStack = 6 OR filaStack=7 THEN SET L_Mode=7;
        #shift_normal_entrance_f #shift_normal_entrance_t #ENTRADA NORMAL
		WHEN filaStack = 8 OR filaStack=9 THEN SET L_Mode=5;
        #shift_late_entrance_f #shift_late_entrance_t #ATRASADO
		WHEN filaStack = 10 OR filaStack=11 THEN SET L_Mode=3;
        #shift_early_depart_f #shift_early_depart_t #SALIDA TEMPRANA
		WHEN filaStack = 14 OR filaStack=15 THEN SET L_Mode=2;
        #shift_normal_depart_f #shift_normal_depart_t #SALIDA NORMAL
		WHEN filaStack = 16 OR filaStack=17 THEN SET L_Mode=4;
        #shift_late_depart_f #shift_late_depart_t #SALIDA TARDE
    ELSE SET L_Mode=6;
    END CASE;

#call unis.getShift(idTurno,hora,@a);
RETURN L_Mode;
END;
