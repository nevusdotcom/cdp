CREATE PROCEDURE unis.getProyectWorkers(IN proyectName VARCHAR(50), IN tipo VARCHAR(50), IN fromDate VARCHAR(8),
                                        IN toDate      VARCHAR(8))
  BEGIN

	#Retorna la lista de trabajadores entre fechas de un determinado proyecto
    #Hay que considerar que se considera participe del proyecto una persona cuando es añadida
    #A este, como existen dos triggers de temploye a temploye2 que actualiza el estado
    #Cuando se registra o modifica, el between entre fechas esta destinado a temploye2 
    DECLARE actualWorkerId, flagNotFound, cantidadFilas, filaActual,rut_ACTUAL,cantidadMarcas_ACTUAL, USER_ID_ACTUAL  INT;
    DECLARE C_Name_ACTUAL VARCHAR(150);
    DECLARE rverificador_ACTUAL VARCHAR(1);
    DECLARE especialidad_ACTUAL, cargo_ACTUAL VARCHAR(50);
    DECLARE oficina_ACTUAL VARCHAR(30);
    DECLARE foto_ACTUAL BLOB;
    #DECLARE tipoResultado INT default 0;
	DECLARE ID_NORMAL INT DEFAULT 1;
	DECLARE ID_LICENCIA INT DEFAULT 2;
	DECLARE ID_DESCANSO INT DEFAULT 3;
    #DECLARE tipoResultado INT default 0;
    
		#cur_1:registrados
		DECLARE cur_1 CURSOR 
        FOR 
        SELECT DISTINCT temploye.L_UID
		FROM temploye
		JOIN coffice ON coffice.c_code=temploye.C_Office
		#JOIN tenter ON tenter.L_UID=temploye.L_UID
		JOIN temploye2 ON temploye2.L_UID = temploye.L_UID
		WHERE coffice.c_name=proyectName
		AND CAST(temploye2.aggregateDate AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);
		#AND tenter.L_UID > 0 AND CAST(C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);
        #END IF;
        
	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET flagNotFound = 1;
    DROP TEMPORARY TABLE IF EXISTS proyectWorkers;
    
    create temporary table proyectWorkers(
    foto BLOB,
    L_ID int not null,
    SIGMA_ID int, #reclutamiento ID
	C_Name varchar(150) not null default '',
	#C_Date varchar(150) not null default '',
    rut int,
    rverificador varchar(1),
    especialidad varchar(50) default '',
    cargo varchar(50) default '',
    officeName varchar(50),
    departament varchar(30)#,
    #cantidadMarcas int
    );
    
    CASE 
		WHEN (LOWER(tipo)='registrados') THEN 
		OPEN cur_1;
        SELECT FOUND_ROWS() into cantidadFilas ;
        SET filaActual=0;
        WHILE filaActual<cantidadFilas DO
		SET filaActual=filaActual+1;
		SET especialidad_ACTUAL='';
		SET cargo_ACTUAL='';
		SET oficina_ACTUAL='';
        SET USER_ID_ACTUAL='';
        SET foto_ACTUAL=NULL;
        SET C_Name_ACTUAL=NULL;
        SET rut_ACTUAL=NULL;
        SET rverificador_ACTUAL=NULL;

		#REPEAT
		FETCH cur_1 INTO actualWorkerId;
		#call unis.debug_on(concat(actualWorkerId));
		SELECT reclutamiento.USER_ID, reclutamiento.especialidad, reclutamiento.cargo
		INTO USER_ID_ACTUAL, especialidad_ACTUAL, cargo_ACTUAL
		FROM reclutamiento
		WHERE reclutamiento.L_UID=actualWorkerId;
    
		SELECT tuser.C_Name, tuser.tuser_rut, tuser.tuser_verificador
		INTO C_Name_ACTUAL, rut_ACTUAL, rverificador_ACTUAL
		FROM tuser
		WHERE tuser.L_ID=actualWorkerId;
    
		#DE MOMENTO QUEDARA ASI, PERO SE DEBE MODIFICAR EL TRIGGER 
		#DE ACTUALIZACION DE PROYECTO A TAMBIEN ACTUALIZACION DE OFICINA
		SELECT cpost.c_name INTO oficina_ACTUAL FROM cpost
		JOIN temploye ON temploye.C_Post=cpost.c_code
		WHERE temploye.L_UID=actualWorkerId;
        
        SELECT iuserpicture.B_Picture INTO foto_ACTUAL FROM iuserpicture
		WHERE iuserpicture.L_UID=actualWorkerId;
		#SELECT COUNT(DISTINCT tenter.C_Date)
		#INTO cantidadMarcas_ACTUAL
		#FROM tenter2
		#WHERE tenter2.L_UID=actualWorkerId
		#AND CAST(C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);

		INSERT INTO proyectWorkers
		(foto,
        L_ID,
		SIGMA_ID,
		C_Name,
		rut,
		rverificador,
		especialidad,
		cargo,
		officeName,
		departament)#,
		#cantidadMarcas)
		VALUES
		(foto_ACTUAL,
        actualWorkerId,
		USER_ID_ACTUAL,
		C_Name_ACTUAL,#
		rut_ACTUAL,
		rverificador_ACTUAL,
		especialidad_ACTUAL,
		cargo_ACTUAL,
		proyectName,
		oficina_ACTUAL
		);#,
    #cantidadMarcas_ACTUAL);

		END WHILE; 
		#END REPEAT;
		CLOSE cur_1;

        WHEN (LOWER(tipo)='presentes') THEN
			INSERT INTO proyectWorkers
				(foto,
                L_ID,
				SIGMA_ID,
				C_Name,
				rut,
				rverificador,
				especialidad,
				cargo,
				officeName,
				departament)
            SELECT 
				iuserpicture.B_Picture,
				tEmploye.L_UID, #as 'L_ID',
				reclutamiento.USER_ID, #as 'SIGMA_ID',
				tuser.C_Name, #as 'C_Name',
				tuser.tuser_rut, #as 'rut', 
				tuser.tuser_verificador, #as 'rverificador',
				reclutamiento.especialidad, #as 'especialidad', 
				reclutamiento.cargo, #as 'cargo',
				proyectName, #as 'officeName',
				cpost.c_name #as 'departament'
            FROM tuser
				JOIN tEmploye ON tuser.L_ID = tEmploye.L_UID
				JOIN cOffice ON tEmploye.C_Office = cOffice.c_code
				JOIN tEnter ON tuser.L_ID = tEnter.L_UID
				JOIN tEnter2 ON tEnter.tenter_id=tEnter2.ID
                LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
				LEFT JOIN reclutamiento ON reclutamiento.L_UID=tEmploye.L_UID
				LEFT JOIN cpost ON cpost.c_code=temploye.C_Post
            WHERE
				tEnter.L_UID>0
				AND tEnter.C_DATE=CAST(toDate as SIGNED) ##20170322
				AND tenter2.L_MODE!=4
				AND tenter2.L_MODE!=2
				AND tenter2.L_MODE!=1
				AND tEmploye.assistance_status_id != ID_LICENCIA
				AND tEmploye.assistance_status_id != ID_DESCANSO
				AND cOffice.c_name LIKE proyectName ##'sigmasa';
                GROUP BY L_ID;
	
    WHEN (LOWER(tipo)='atrasados') THEN
    			
                INSERT INTO proyectWorkers
				(foto,
                L_ID,
				SIGMA_ID,
				C_Name,
				rut,
				rverificador,
				especialidad,
				cargo,
				officeName,
				departament)
            SELECT 
				iuserpicture.B_Picture,
				tEmploye.L_UID, #as 'L_ID',
				reclutamiento.USER_ID, #as 'SIGMA_ID',
				tuser.C_Name, #as 'C_Name',
				tuser.tuser_rut, #as 'rut', 
				tuser.tuser_verificador, #as 'rverificador',
				reclutamiento.especialidad, #as 'especialidad', 
				reclutamiento.cargo, #as 'cargo',
				proyectName, #as 'officeName',
				cpost.c_name #as 'departament'
                FROM tenter
                JOIN temploye on temploye.L_UID=tenter.L_UID
                JOIN coffice on coffice.c_code=tenter.C_Office
                JOIN tEnter2 ON tEnter.tenter_id=tEnter2.ID
                JOIN tuser ON tuser.L_ID=tEmploye.L_UID
                LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
                LEFT JOIN reclutamiento ON reclutamiento.L_UID=tEmploye.L_UID
                LEFT JOIN cpost ON cpost.c_code=temploye.C_Post
                WHERE tenter.C_Date=CAST(toDate as SIGNED)
                AND coffice.c_name=proyectName
                AND tenter.L_UID>0
                AND tenter2.L_MODE=3
                AND tEmploye.assistance_status_id =ID_NORMAL;
	
	WHEN (LOWER(tipo)='licencia') THEN
    
    INSERT INTO proyectWorkers
				(foto,
                L_ID,
				SIGMA_ID,
				C_Name,
				rut,
				rverificador,
				especialidad,
				cargo,
				officeName,
				departament)
            SELECT 
				iuserpicture.B_Picture,
                tEmploye.L_UID, #as 'L_ID',
				reclutamiento.USER_ID, #as 'SIGMA_ID',
				tuser.C_Name, #as 'C_Name',
				tuser.tuser_rut, #as 'rut', 
				tuser.tuser_verificador, #as 'rverificador',
				reclutamiento.especialidad, #as 'especialidad', 
				reclutamiento.cargo, #as 'cargo',
				proyectName, #as 'officeName',
				cpost.c_name #as 'departament' 
			FROM tuser
            JOIN temploye on tuser.L_ID=temploye.L_UID
            JOIN coffice on coffice.c_code=temploye.C_Office
			LEFT JOIN reclutamiento ON reclutamiento.L_UID=tEmploye.L_UID
            LEFT JOIN cpost ON cpost.c_code=temploye.C_Post
            LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
            JOIN tenter ON tenter.L_UID=tuser.L_ID
            WHERE tuser.L_ID>0
            AND coffice.c_name=proyectName
            AND temploye.C_Staff=ID_LICENCIA;
            #AND tenter.C_Date=CAST(toDate as SIGNED);
	
	WHEN (LOWER(tipo)='descanso') THEN
    
    INSERT INTO proyectWorkers
				(foto,
                L_ID,
				SIGMA_ID,
				C_Name,
				rut,
				rverificador,
				especialidad,
				cargo,
				officeName,
				departament)
            SELECT 
				iuserpicture.B_Picture,
                tEmploye.L_UID, #as 'L_ID',
				reclutamiento.USER_ID, #as 'SIGMA_ID',
				tuser.C_Name, #as 'C_Name',
				tuser.tuser_rut, #as 'rut', 
				tuser.tuser_verificador, #as 'rverificador',
				reclutamiento.especialidad, #as 'especialidad', 
				reclutamiento.cargo, #as 'cargo',
				proyectName, #as 'officeName',
				cpost.c_name #as 'departament' 
			FROM tuser
            JOIN temploye on temploye.L_UID=tuser.L_ID
            JOIN coffice on coffice.c_code=temploye.C_Office
			LEFT JOIN reclutamiento ON reclutamiento.L_UID=tEmploye.L_UID
            LEFT JOIN cpost ON cpost.c_code=temploye.C_Post
            LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
            WHERE tuser.L_ID>0
            AND coffice.C_name=proyectName
            AND tEmploye.assistance_status_id=ID_DESCANSO;
	
    	WHEN (LOWER(tipo)='faltantes') THEN
        
        INSERT INTO proyectWorkers
				(foto,
                L_ID,
				SIGMA_ID,
				C_Name,
				rut,
				rverificador,
				especialidad,
				cargo,
				officeName,
				departament)
		SELECT 
				iuserpicture.B_Picture,
                tEmploye.L_UID, #as 'L_ID',
				reclutamiento.USER_ID, #as 'SIGMA_ID',
				tuser.C_Name, #as 'C_Name',
				tuser.tuser_rut, #as 'rut', 
				tuser.tuser_verificador, #as 'rverificador',
				reclutamiento.especialidad, #as 'especialidad', 
				reclutamiento.cargo, #as 'cargo',
				proyectName, #as 'officeName',
				cpost.c_name #as 'departament' 
                ##
		FROM tuser
        JOIN temploye on temploye.L_UID=tuser.L_ID
        JOIN coffice on unis.temploye.C_Office=unis.coffice.c_code
        LEFT JOIN iuserpicture ON iuserpicture.L_UID=tuser.L_ID
		LEFT JOIN reclutamiento ON reclutamiento.L_UID=tEmploye.L_UID
		LEFT JOIN cpost ON cpost.c_code=temploye.C_Post
        WHERE tEmploye.assistance_status_id=ID_NORMAL
        #AND tUser.C_RegDate <= CAST(toDate as SIGNED)
        AND cOffice.c_name = proyectName
        AND tuser.L_ID not in (SELECT DISTINCT tEnter.L_UID
        FROM tEnter
        JOIN tEmploye ON tEmploye.L_UID=tEnter.L_UID
        JOIN COffice ON tEmploye.C_Office=COffice.c_code
        JOIN tUser  ON tEnter.L_UID=tuser.L_ID
        JOIN tEnter2 ON tEnter.tenter_id=tEnter2.ID
        WHERE
        tEnter.L_UID > 0
		AND tEmploye.assistance_status_id=ID_NORMAL #tEmploye.C_Staff='0001'
		AND coffice.c_name=proyectName
		AND tEnter2.L_MODE !=4
		AND tEnter2.L_MODE !=2
        #AND tEnter.L_MODE !=4
        #AND tEnter.L_MODE !=2
        AND tEnter.C_Date=CAST(toDate as SIGNED));
    
	END CASE;# IF; # END CASE DE TIPO DATO 
    
		SELECT 
			HEX(foto) as 'B_Picture',
			L_ID as 'L_ID',
			SIGMA_ID as 'SIGMA_ID', #reclutamiento ID
			C_Name as 'C_Name',
	#C_Date varchar(150) not null default '',
			rut as 'rut',
            rverificador as 'rverificador',
            especialidad as 'especialidad',
            cargo as 'cargo',
            officeName as 'officeName',
            departament as 'departament'#,
        FROM
			proyectWorkers;
  END;
