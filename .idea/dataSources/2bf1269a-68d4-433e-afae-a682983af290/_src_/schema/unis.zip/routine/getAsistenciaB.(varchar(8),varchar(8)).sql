CREATE PROCEDURE unis.getAsistenciaB(IN fromDate VARCHAR(8), IN toDate VARCHAR(8))
  BEGIN

    DECLARE a, b, cantidadFilas, filaActual  INT;
    
    DECLARE cur_1 CURSOR FOR SELECT DISTINCT tenter.L_UID
                             FROM tenter
                             WHERE tenter.L_UID > 0 AND CAST(C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED);

	DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET b = 1;
    DROP TEMPORARY TABLE IF EXISTS asistencia;
    
    create temporary table asistencia(
    L_ID varchar(150) not null,
	C_Name varchar(150) not null default '',
	C_Date varchar(150) not null default '',
	entrada varchar(150) not null default '',
	salida varchar(150) not null default ''
    );

    OPEN cur_1;
    select FOUND_ROWS() into cantidadFilas ;
    SET filaActual=0;
    
    while filaActual<cantidadFilas do
    set filaActual=filaActual+1;
    #REPEAT
      FETCH cur_1
      INTO a;
	call unis.debug_on(concat(a));

      INSERT INTO asistencia SELECT distinct
                               tuser.L_ID,
                               tuser.C_Name,
                               tenter.C_Date,
                               STR_TO_DATE(CAST(MIN(tenter.C_Time) as char),'%H%i%s') entrada,
                               STR_TO_DATE(CAST(MAX(tenter.C_Time) as char),'%H%i%s') salida

                             FROM
                               tuser
                               INNER JOIN
                               tenter ON tenter.L_UID = tuser.L_ID
                             WHERE
                               tenter.L_UID > 0
                               AND CAST(C_Date AS SIGNED) BETWEEN CAST(fromDate AS SIGNED) AND CAST(toDate AS SIGNED)
                               #AND tenter.C_Date = '20170504'
                               AND tuser.L_ID = a
                               GROUP BY tuser.L_ID,tenter.C_Date
                             ORDER BY tenter.C_Date,tenter.L_UID;

    end while;
    #END REPEAT;
    CLOSE cur_1;
    SELECT *
    FROM
	asistencia;
  END;
