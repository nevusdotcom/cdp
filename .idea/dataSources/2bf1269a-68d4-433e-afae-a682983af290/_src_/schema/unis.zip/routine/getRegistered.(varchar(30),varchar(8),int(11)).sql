CREATE PROCEDURE unis.getRegistered(IN proyectName VARCHAR(30), IN dateIn VARCHAR(8), IN cantidadVista INT)
  BEGIN

SELECT  tEnter.L_UID,tEnter.C_Name,cOffice.C_Name project,tEnter.C_Date,tEnter.C_Time,tEnter.C_Unique,tEnter.L_Mode,#HEX(iUserPicture.B_Picture) B_Picture,tEnter.C_Time,
                CASE
                    WHEN L_Mode = 1 THEN 'ATTEND' 
                    WHEN L_Mode = 5 OR L_Mode = 3 THEN 'ENTRADA' 
                    WHEN L_Mode = 4 THEN 'SALIDA'
                    WHEN L_Mode = 2 THEN 'SALIDA TEMPRANA'
                END AS tipo 
        FROM tEnter
            INNER JOIN cOffice ON cOffice.c_code = tEnter.C_Office
            LEFT JOIN iUserPicture ON iUserPicture.L_UID = tEnter.L_UID
        WHERE tEnter.L_UID>0
            AND tEnter.C_Date = dateIn COLLATE utf8_general_ci #'20170525' 
            AND cOffice.c_name=LOWER(proyectName)
            ORDER BY tEnter.tenter_id DESC
             LIMIT 10;

END;
