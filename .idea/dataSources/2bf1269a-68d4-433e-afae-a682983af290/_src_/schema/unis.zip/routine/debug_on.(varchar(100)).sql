CREATE PROCEDURE unis.debug_on(IN p_proc_id VARCHAR(100))
  begin
  call debug_insert(p_proc_id,concat('Debug Started :',now()));
end;
