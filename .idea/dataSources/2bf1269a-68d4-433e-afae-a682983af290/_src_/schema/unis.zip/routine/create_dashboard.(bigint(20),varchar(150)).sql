CREATE PROCEDURE unis.create_dashboard(IN dia BIGINT, IN project VARCHAR(150))
  begin
	
	DECLARE registrados int default -1;
	DECLARE presentes int default -1;
	DECLARE atrasados int default -1;
	DECLARE licencia int default -1;
	declare descanso int default -1;
	declare faltantes int default -1;
	DECLARE diahora VARCHAR(150) default '235959' COLLATE utf8_unicode_ci;
	set  diahora = CONCAT(CAST(dia AS CHAR),diahora);
	
	SELECT COUNT(*)
	into registrados
	FROM tUser
    JOIN tEmploye ON tUser.L_ID=tEmploye.L_UID
    JOIN cOffice ON tEmploye.C_Office = cOffice.c_code
    where
    tUser.C_RegDate < diahora
    ##Lo ideal es que se haga el join usando la id del campo que esta designado ahora como proyecto
    AND cOffice.c_name = project;
    
	SELECT COUNT(DISTINCT tUser.L_ID)
	into presentes
		FROM tUser
		JOIN tEmploye ON tUser.L_ID = tEmploye.L_UID
		JOIN cOffice ON tEmploye.C_Office = cOffice.c_code
		JOIN tEnter ON tUser.L_ID = tEnter.L_UID
	WHERE
		tEnter.L_UID>0
		AND tEnter.C_DATE=dia ##20170322
		AND  tEnter.L_Mode != 4 
		AND tEnter.L_Mode != 2 
		AND tEmploye.C_Staff != '0002' 
		AND tEmploye.C_Staff != '0003'
		##revisar nuevamente lo de la id del proyecto y su funcion
		AND cOffice.c_name LIKE project; ##'sigmasa';
		
 ##ATRASADOS
  SELECT COUNT(DISTINCT tenter.L_UID)
  into atrasados
  from tenter
  join temploye on temploye.L_UID=tenter.L_UID
  join coffice on coffice.c_code=tenter.C_Office
  #FROM dbo.tEnter as logged, dbo.tEmploye as logOffice, dbo.COffice as offices
  where tenter.C_Date=dia
  and coffice.c_name=project
  and tenter.L_UID>0
  and tenter.L_Mode=3
  and temploye.C_Office='0001';
  #0001:NORMAL - 0002:LICENCIA - 0003:DESCANSO
  
  SELECT COUNT(tuser.L_ID)
  into licencia
  from tuser
  join temploye on tuser.L_ID=temploye.L_UID
  join coffice on coffice.c_code=temploye.C_Office
  where tuser.L_ID>0
  and coffice.c_name=project
  and temploye.C_Staff='0002';
  
  #offices -> coffice
  #registrados -> tuser
  #logoffice -> temploye
  #SELECT @descanso = COUNT(registrados.L_ID)
  select count(tuser.L_ID)
  into descanso
  from tuser
  join temploye on temploye.L_UID=tuser.L_ID
  join coffice on coffice.c_code=temploye.C_Office
  where tuser.L_ID>0
  and coffice.C_name=project
        #--CODES .- 0001:NORMAL - 0002:LICENCIA - 0003:DESCANSO
  and temploye.C_Staff='0003';
  
  #TODOS LOS FALTANTES DE UNA DETERMINADA FECHA:
  #SELECT @faltantes = COUNT(*) FROM tUser
  select count(*) 
  into faltantes
  from tuser
  join temploye on temploye.L_UID=tuser.L_ID
  join coffice on unis.temploye.C_Office=unis.coffice.c_code
  #join coffice on temploye.C_Office=cOffice.c_code
  where temploye.C_Staff ='0001'
    AND tUser.C_RegDate < diahora
    AND cOffice.c_name = project
	AND tUser.L_ID not in (SELECT DISTINCT tEnter.L_UID
      FROM tEnter
        JOIN tEmploye ON tEmploye.L_UID=tEnter.L_UID
        JOIN COffice ON tEmploye.C_Office=COffice.C_Code
        JOIN tUser  ON tEnter.L_UID=tUser.L_ID
      WHERE
        ##CONDITIONS
        tEnter.L_UID > 0
		AND tEmploye.C_Staff='0001'
        AND tEnter.L_MODE !=4
        AND tEnter.L_MODE !=2
        AND tEnter.C_DATE=dia);
  
  select registrados,presentes,atrasados,licencia,descanso,faltantes;
  end;
