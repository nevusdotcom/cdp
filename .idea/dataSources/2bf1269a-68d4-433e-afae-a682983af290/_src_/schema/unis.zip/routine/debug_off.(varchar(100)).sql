CREATE PROCEDURE unis.debug_off(IN p_proc_id VARCHAR(100))
  begin
  call debug_insert(p_proc_id,concat('Debug Ended :',now()));
  select debug_output from debug where debug.id = p_proc_id order by line_id;
  delete from debug where debug.id = p_proc_id;
end;
