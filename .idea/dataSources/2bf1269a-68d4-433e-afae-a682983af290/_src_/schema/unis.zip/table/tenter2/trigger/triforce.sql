CREATE TRIGGER unis.triforce
AFTER INSERT ON unis.tenter2
FOR EACH ROW
  BEGIN

   DECLARE ACTUAL_Area VARCHAR(50) DEFAULT 'AREA NO REGISTRADA';
   DECLARE ACTUAL_Proyect VARCHAR(30);
   DECLARE
   ACTUAL_TENTER2_ID,
   ACTUAL_L_UID,
   ACTUAL_HOLIDAY_id,
   ACTUAL_SHIFT_id,
   ACTUAL_SHIFT_Gap,
   ACTUAL_SHIFT_hours,
   ACTUAL_L_Mode,
   ACTUAL_ENTRANCE_Terminal_ID,
   ACTUAL_EXIT_Terminal_ID,
   ASSISTANCE_STATUS_ID_ACTUAL,
   ACTUAL_ENTRANCE_Time,
   ACTUAL_EXIT_Time,
   ACTUAL_Date,
   ACTUAL_Search_Date,
   ACTUAL_Horas_Trabajadas,
   INCIDENCE_ID,
   flag_sin_incidencia_assistance_status INT;
   
   	SET ACTUAL_L_Mode=NEW.L_MODE;
    SET ACTUAL_SHIFT_id=NEW.SHIFT_ID;
	SET ACTUAL_L_UID=NEW.L_UID;
    SET ACTUAL_TENTER2_ID=NEW.ID;

   #EN TENTER2 SIEMPRE LLEGAN CON L_UID>1
	
	#ENTRADA TEMPRANA - ENTRADA NORMAL - ENTRADA TARDE
    CASE 
   WHEN (ACTUAL_L_Mode =7 OR ACTUAL_L_Mode =5 OR ACTUAL_L_Mode =3) THEN 
   
		SELECT  C_Date, C_Time, L_TID, C_Office INTO  ACTUAL_Date, ACTUAL_ENTRANCE_Time, ACTUAL_ENTRANCE_Terminal_ID,ACTUAL_Proyect FROM tenter WHERE tenter.tenter_id=NEW.ID;
        SELECT temploye.assistance_status_id INTO ASSISTANCE_STATUS_ID_ACTUAL #OK
        FROM temploye WHERE temploye.L_UID=ACTUAL_L_UID;#NEW.L_UID;
        
        SELECT area.nombre INTO ACTUAL_Area FROM area #OK 
        WHERE area.ID=NEW.AREA_ID;#OK
        
        #CASO LICENCIA MEDICA
        CASE
        WHEN (ASSISTANCE_STATUS_ID_ACTUAL=2) THEN #OK
        
        INSERT INTO incidents
				(incidents_name,
				incidents_description,
				incidents_date,
				incidents_time,
				L_UID,
		       c_office,
               tenter2_id)
            VALUES (
            'Asistencia con Licencia Medica',
            CONCAT('La persona a ingresado a "',ACTUAL_Area,'" teniendo una licencia medica'),
            ACTUAL_Date,
            ACTUAL_ENTRANCE_Time,
            ACTUAL_L_UID,#NEW.L_UID,
            ACTUAL_Proyect,
            ACTUAL_TENTER2_ID); #OK 
        
		#CASO DESCANSO
        WHEN (ASSISTANCE_STATUS_ID_ACTUAL=3) THEN
        
			INSERT INTO incidents
				(incidents_name,
				incidents_description,
				incidents_date,
				incidents_time,
				L_UID,
	          c_office,
              tenter2_id)
            VALUES (
            'Asistencia en dia no laboral',
            CONCAT('La persona a ingresado a "',ACTUAL_Area,'" cuando se encuentra en periodo de descanso'),
            ACTUAL_Date,
            ACTUAL_ENTRANCE_Time,
            ACTUAL_L_UID,#NEW.L_UID,
            ACTUAL_Proyect,
            ACTUAL_TENTER2_ID); 
		ELSE SET flag_sin_incidencia_assistance_status=1;
		        
        END CASE; #FIN INCIDENCIA POR DESCANSO O LICENCIA
        
	#SALIDA TEMPRANA - SALIDA NORMAL - SALIDA TARDE
    #AQUI SE DEBEN AGREGAR LOS STATS

    ELSE#WHEN (ACTUAL_L_Mode=2 OR ACTUAL_L_Mode=4 OR ACTUAL_L_Mode=6 ) THEN  
        
    SELECT CAST(C_Date AS SIGNED), CAST(C_Time AS SIGNED), L_TID, C_Office INTO ACTUAL_Date, ACTUAL_EXIT_Time, ACTUAL_EXIT_Terminal_ID,ACTUAL_Proyect FROM tenter WHERE tenter.tenter_id=NEW.ID;
    
    SELECT shift.shift_gap,shift.shift_hours INTO ACTUAL_SHIFT_Gap,ACTUAL_SHIFT_hours FROM shift
    WHERE shift.shift_id=ACTUAL_SHIFT_id;#NEW.SHIFT_ID;
    IF ACTUAL_SHIFT_Gap >0 THEN
		SET ACTUAL_Search_Date=ACTUAL_Date-ACTUAL_SHIFT_Gap;
	ELSE SET ACTUAL_Search_Date=ACTUAL_Date;
	END IF;
    
    SELECT MIN(CAST(tenter.C_Time AS SIGNED)), tenter.L_TID INTO ACTUAL_ENTRANCE_Time, ACTUAL_ENTRANCE_Terminal_ID FROM tenter 
			JOIN tenter2 ON tenter2.ID=tenter.tenter_id
            WHERE tenter2.L_UID=ACTUAL_L_UID#NEW.L_UID
			AND tenter.C_Date=CAST(ACTUAL_Search_Date AS CHAR)
			AND (tenter2.L_MODE = 7 OR tenter2.L_MODE = 5 OR tenter2.L_MODE = 3) ;

    SET ACTUAL_Horas_Trabajadas=ACTUAL_EXIT_Time-ACTUAL_ENTRANCE_Time;
    
    IF (ACTUAL_ENTRANCE_Time=0 OR ACTUAL_ENTRANCE_Time IS NULL) THEN
			
            SET ACTUAL_Horas_Trabajadas=0;
            
			SELECT area.nombre INTO ACTUAL_Area FROM area
            WHERE area.ID=ACTUAL_EXIT_Terminal_ID;
            
            INSERT INTO incidents
				(incidents_name,
				incidents_description,
				incidents_date,
				incidents_time,
				L_UID,
                c_office,
                tenter2_id)
            VALUES (
            'Salida de turno sin marcar entrada',
            CONCAT('La persona a salido desde "',ACTUAL_Area,'" sin haber marcado una entrada durante el dia'),
            ACTUAL_Date,
            ACTUAL_EXIT_Time,
            ACTUAL_L_UID,#NEW.L_UID,
            ACTUAL_Proyect,
            ACTUAL_TENTER2_ID);
            
           SELECT LAST_INSERT_ID() INTO INCIDENCE_ID;
       
        END IF; #FIN CASO INCIDENCIA
        
	 SELECT holiday.ID INTO ACTUAL_HOLIDAY_id FROM holiday WHERE holiday.date=CAST(ACTUAL_Date AS SIGNED); 
        #INSERT DAILY STATS
		
        INSERT INTO daily_stats
				(L_UID,
				daily_stats_date,
				daily_stats_h_reales,
				daily_stats_h_fixed,
				daily_stats_c_office,
                daily_stats_shift,
                incident_id,
                holiday_id,
                tenter2_id)
            VALUES (
            ACTUAL_L_UID,#NEW.L_UID,
            ACTUAL_Date,
            ACTUAL_Horas_Trabajadas,
            ACTUAL_SHIFT_hours,
            ACTUAL_Proyect,
            ACTUAL_SHIFT_id,#NEW.SHIFT_ID,
            INCIDENCE_ID,
            ACTUAL_HOLIDAY_id,
            ACTUAL_TENTER2_ID);
	
    END CASE;
        
END
;
