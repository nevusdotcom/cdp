CREATE TRIGGER unis.triggerr
AFTER INSERT ON unis.tenter
FOR EACH ROW
  BEGIN

####
	DECLARE ACTUAL_ID int default 0;
    DECLARE ACTUAL_SHIFT_ID int default 0;
   DECLARE ACTUAL_STATUS_ID int default -1;
   DECLARE ACTUAL_AREA_ID int default -1;
   DECLARE ACTUAL_ASSISTANCE_STATUS_ID int default 1;
   DECLARE ACTUAL_ACCREDITED_ID int default -1;
   DECLARE L_ModeShift INT DEFAULT -1;#NEW.L_Mode;
   
   #INSERT into debug (id) VALUES ( CONCAT('GATITO123 CHAN CHAN ',CAST(NEW.tenter_id as CHAR)));
   SET ACTUAL_ID=NEW.tenter_id;
   #INSERT into debug (id) VALUES ( CONCAT('GATITO123 CHAN CHAN ',CAST(ACTUAL_ID as CHAR)));

   
   IF (NEW.L_UID > 0) THEN
   
		SELECT DISTINCT temploye.shift_id,temploye.assistance_status_id INTO ACTUAL_SHIFT_ID,ACTUAL_ASSISTANCE_STATUS_ID from temploye
		WHERE temploye.L_UID=NEW.L_UID;
        
		IF (NEW.L_Mode=1) THEN
			
            SELECT shift.shift_id INTO ACTUAL_SHIFT_ID FROM shift
            JOIN temploye ON temploye.shift_id=shift.shift_id#
            WHERE temploye.L_UID=NEW.L_UID;
            
            SET L_ModeShift=getShiftChan(ACTUAL_SHIFT_ID, CAST(SUBSTR(NEW.C_Time,1,4) AS SIGNED));
            
            #SELECT getShiftChan(1, 800) INTO L_ModeShift;
            
		ELSE SET L_ModeShift=NEW.L_Mode;

        END IF;
        
		SELECT 
		area_terminal.AREA_ID
		INTO ACTUAL_AREA_ID FROM
		area_terminal
		WHERE
		area_terminal.TERMINAL_ID = NEW.L_TID;
      
		SELECT DISTINCT
		reclutamiento.status, reclutamiento.status_acreditacion
		INTO ACTUAL_STATUS_ID , ACTUAL_ACCREDITED_ID FROM
		reclutamiento
		WHERE
			reclutamiento.L_UID = NEW.L_UID;
        
        #INSERT INTO tenter2 VALUES (ACTUAL_ID,1,1,1,1,1,1);
		INSERT INTO tenter2 VALUES (ACTUAL_ID,ACTUAL_AREA_ID,ACTUAL_SHIFT_ID,ACTUAL_STATUS_ID,NEW.L_UID,ACTUAL_ASSISTANCE_STATUS_ID,ACTUAL_ACCREDITED_ID,L_ModeShift);

		#INSERT INTO tenter2
        #VALUES
		#(1,#NEW.tenter_id,
		#1,#ACTUAL_AREA_ID,
		#1,#ACTUAL_SHIFT_ID,
		#1,#ACTUAL_STATUS_ID,
		#1,#NEW.L_UID,
		#1,#ACTUAL_ASSISTANCE_STATUS_ID,
		#1,#ACTUAL_ACCREDITED_ID,
        #1); #L_ModeShift);
        
		#(ID,
		#AREA_ID,
		#SHIFT_ID,
		#STATUS_ID,
		#L_UID,
		#ASSISTANCE_STATUS_ID,
		#ACCREDITED_ID,
        #L_MODE)
		#VALUES
		#(NEW.tenter_id,
		#ACTUAL_AREA_ID,
		#ACTUAL_SHIFT_ID,
		#ACTUAL_STATUS_ID,
		#NEW.L_UID,
		#ACTUAL_ASSISTANCE_STATUS_ID,
		#ACTUAL_ACCREDITED_ID,
        #L_ModeShift);
        
		END IF;

####


END;
