CREATE TRIGGER unis.after_update_proyect
AFTER UPDATE ON unis.temploye
FOR EACH ROW
  BEGIN
	
    DECLARE dateReg VARCHAR(8);
    
    #SELECT substr(tuser.C_RegDate,1,8) INTO dateReg FROM tuser WHERE tuser.L_ID=NEW.L_UID;

   IF NEW.C_Office <> OLD.C_Office THEN
   
		IF (SELECT EXISTS(
			SELECT * FROM temploye2 
            #JOIN tuser ON tuser.L_ID=temploye2.L_UID
            WHERE temploye2.L_UID=NEW.L_UID AND temploye2.aggregateDate=CAST(CURDATE() AS SIGNED)#CAST(dateReg AS SIGNED)#
		))
		THEN 
			UPDATE temploye2 SET temploye2.C_Office=NEW.C_Office WHERE temploye2.L_UID=NEW.L_UID AND temploye2.aggregateDate=CAST(CURDATE() AS SIGNED);#CAST(dateReg AS SIGNED);#CAST(CURDATE() AS SIGNED);
		ELSE
			INSERT INTO temploye2 (L_UID,C_Office,aggregateDate) VALUES (NEW.L_UID,NEW.C_Office,CAST(CURDATE() AS SIGNED));#CAST(dateReg AS SIGNED));#
   END IF;
   END IF;
   

END;
