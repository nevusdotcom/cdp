CREATE TRIGGER unis.after_insert_proyect
AFTER INSERT ON unis.temploye
FOR EACH ROW
  BEGIN
	INSERT INTO temploye2 (L_UID,C_Office,aggregateDate) VALUES (NEW.L_UID,NEW.C_Office,CAST(CURDATE() AS SIGNED));#CAST(dateReg AS SIGNED));#

END;
